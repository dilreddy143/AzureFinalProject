When you open Tableau visualisation files, to see the data/graph in the report please connect to sql server using below connection details

username: dilipuser1
password: password@1